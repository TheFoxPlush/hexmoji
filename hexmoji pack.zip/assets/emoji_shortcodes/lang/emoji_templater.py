import dfpyre
import json

with open("assets/emoji_shortcodes/lang/en_us.json","r") as basefile:
    data = json.load(basefile)

strings = []

emoji_and_shorthands = {}

for shorthand,emoji in data.items():
    if emoji not in emoji_and_shorthands:
        emoji_and_shorthands[emoji] = []
    emoji_and_shorthands[emoji]+=[shorthand[1:-1]]

string = ''

for emoji,shorthands in emoji_and_shorthands.items():
    package = f"{emoji}:{";".join(shorthands)}#"
    if len(string)+len(package)>1000:
        strings.append(string[:-1])
        string = ""
    string+=package
if string != "":
    strings.append(string[:-1])

        
template = []
string_package = []
i = 0

while len(strings)>0:
    string_package.append(strings.pop(0))
    if len(string_package) == 26:
        i+=1
        template.append(dfpyre.set_variable('CreateList',dfpyre.Variable(f'emojis_{i}',scope='local'),*string_package))
        string_package = []

if string_package !=[]:
    i+=1
    template.append(dfpyre.set_variable('CreateList',dfpyre.Variable(f'emojis_{i}',scope='local'),*string_package))

template.append(dfpyre.set_variable("=",dfpyre.Variable("count",scope="local"),i))

j = 0
final = []
for codeblock in template:
    j+=1
    code = dfpyre.function(f'emojis.init.data_{j}',codeblocks=[codeblock]).build()
    final.append("""/give TheFoxPlush ender_chest[custom_name= {extra: [{color: "aqua", underlined: 0b, text: "Function ", strikethrough: 0b, bold: 1b, obfuscated: 0b, italic: 0b}, {color: "dark_aqua", text: "Â» ", bold: 0b, italic: 0b}, {color: "aqua", text: "emojis.init.category.data", italic: 0b}, {color: "aqua", text: "", italic: 0b}], text: ""}, custom_data= {PublicBukkitValues: {"hypercube:codetemplatedata": '{"author":"TheFoxPlush","name":"Â§bÂ§lFunction Â§3Â» Â§bemoji_strings_test","version":1,"code":\""""+code+"""\"}'}}]""")

print(final[7])