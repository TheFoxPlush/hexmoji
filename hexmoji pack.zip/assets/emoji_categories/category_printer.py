import json
import dfpyre

categories = ["activity","food","nature","objects","people","symbols","travel"]

codeblocks = []

for category in categories:
    with open(f"assets/emoji_categories/symbols/{category}.txt","r", encoding="utf8") as emojilistfile:
        emojilist = emojilistfile.read().splitlines()
    print(category)
    emojilist = ";".join(emojilist)
    codeblock = dfpyre.set_variable('=',dfpyre.Variable(category,scope='local'),emojilist)
    codeblocks.append(codeblock)
template = dfpyre.function('emoji_strings',codeblocks=codeblocks)     
result = template.build()
print(result)