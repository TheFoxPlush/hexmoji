#this code places empty pixels at the corners of the images to make them take up the whole sprite

import os
from PIL import Image, ImageDraw

os.chdir(os.path.dirname(__file__))

for folder, _, items in os.walk('.'):
    for item in items:
        if item.endswith('.png'):
            im = Image.open(os.path.join(folder,item)).convert("RGBA")
            x,y = im.size
            px = im.load()
            if "tail" in item:
                if px[0,0][3] == 0:
                    im.putpixel((0,0),(1,0,0,1))
                if px[x-1,y-1][3] == 0:
                    im.putpixel((x-1,y-1),(1,0,0,1))
                im.save(os.path.join(folder,item))
            elif "9_part" in item:
                for x_ in range(0,x,x//3):
                    for y in range(0,30,10):
                        if px[x_,y][3] == 0:
                            im.putpixel((x_,y),(1,0,0,1))
                            print(f"modified at {(x_,y)}")
                        if px[x_+x//3-1,y+9][3] == 0:
                            im.putpixel((x_+x//3-1,y+9),(1,0,0,1))
                            print(f"modified at {(x_+x//3-1,y+9)}")
                        im.save(os.path.join(folder,item))