import dfpyre
import json

char = ord('\ue000')-1

shift_dict = {}

continuous = ''

for i in range(-512,513):
    char+=1
    shift_dict[chr(char)] = i
    continuous+=chr(char)

font_entry = {"providers":[{"type":"space","advances":shift_dict}]}

with open("assets/minecraft/font/shift.json","w") as shiftfile:
    json.dump(font_entry,shiftfile,indent=3)

template = dfpyre.function(f'insert_characters',codeblocks=[dfpyre.set_variable("=",dfpyre.Variable("characters",scope="line"),continuous)])
code = template.build()
print("""/give TheFoxPlush ender_chest[custom_name= {extra: [{color: "aqua", underlined: 0b, text: "Function ", strikethrough: 0b, bold: 1b, obfuscated: 0b, italic: 0b}, {color: "dark_aqua", text: "Â» ", bold: 0b, italic: 0b}, {color: "aqua", text: "emojis.init.category.data", italic: 0b}, {color: "aqua", text: "", italic: 0b}], text: ""}, custom_data= {PublicBukkitValues: {"hypercube:codetemplatedata": '{"author":"TheFoxPlush","name":"Â§bÂ§lFunction Â§3Â» Â§bemoji_strings_test","version":1,"code":\""""+code+"""\"}'}}]""")